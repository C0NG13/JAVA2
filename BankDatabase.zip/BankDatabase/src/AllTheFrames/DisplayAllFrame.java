package AllTheFrames;

import java.awt.event.*;
import javax.swing.*;
import java.awt.*;



@SuppressWarnings("serial")
public class DisplayAllFrame extends JFrame implements ActionListener {

	//constructor
	public DisplayAllFrame(String accounts)
	{	
	
		super("Displaying All Accounts");  // JFrame window caption 
		// System.out.println(accounts.toString()); // error checking stuff
	    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // just closes this form
	    
	    
	    
		// dimensions and margins for box and fields mostly
	    FlowLayout flow = new FlowLayout(FlowLayout.LEFT);
	    setLayout(flow);
	    setSize(1000,1000); // a square box sized form
	    
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS)); // vertical and
        panel.setAlignmentX(Component.LEFT_ALIGNMENT); // left panel alignment

	    panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // add margin around panel

	    //adding things to the panel
	    panel.add(greeting);
	    panel.add(Box.createVerticalStrut(10));
	    greeting1.setText(accounts);
	    panel.add(greeting1);
	    panel.add(Box.createVerticalStrut(10));
	    panel.add(Box.createVerticalStrut(10));  // add spacing between components

	
	    panel.add(Button1);

	    // add the panel to the frame
	    add(panel);


		Button1.addActionListener(this);


	
	
	}
	
	
	
	// create a JPanel for form
    JPanel panel = new JPanel();


    JLabel greeting = new JLabel("Here are all of the accounts:\n"); 
    JLabel greeting1 = new JLabel(""); 
    JButton Button1 = new JButton("finish");
    


	
	
// Error Analysis

    // what to do if button is pushed
	@Override
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		// System.out.println(source); // error checking stuff
		if(source == Button1) // finish
		{	
				
				dispose(); // closes the form
		    	
		    	
		
		}
		
		
		
		
		
		
	}}
