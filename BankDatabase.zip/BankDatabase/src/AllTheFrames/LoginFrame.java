package AllTheFrames;

import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import java.awt.Color;

import BankAccountManagementSystem.Main;


@SuppressWarnings("serial")
public class LoginFrame extends JFrame implements ActionListener {
	//constructor
	public LoginFrame()
	{
		super("Bank Login");  // JFrame window caption 
	    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // just closes this form
	    panel.setBackground(Color.BLACK);
	   
	     usernameLabel.setForeground(Color.WHITE);
	     greeting.setForeground(Color.WHITE);
	     passwordLabel.setForeground(Color.WHITE);
	     
	     setSize(300,275);   
	    
		// dimensions and margins for box and fields mostly
	    FlowLayout flow = new FlowLayout(FlowLayout.LEFT);
	    setLayout(flow);
	    
	    
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS)); // vertical and
        panel.setAlignmentX(Component.LEFT_ALIGNMENT); // left panel alignment

	    panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // add margin around panel
	    
	    usernameField.setMaximumSize(new Dimension(300, 30)); 
	    usernameField.setPreferredSize(new Dimension(300, 30));
	    usernameField.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10)); 
	    
	    passwordField.setMaximumSize(new Dimension(300, 30)); 
	    passwordField.setPreferredSize(new Dimension(300, 30));
	    passwordField.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10)); 
	    


		
	    //adding things to the panel
	    panel.add(greeting);
	    panel.add(Box.createVerticalStrut(10));
	    panel.add(usernameLabel);
	    panel.add(Box.createVerticalStrut(10));
	    panel.add(usernameField);
	    panel.add(Box.createVerticalStrut(10));  // add spacing between components
	    panel.add(passwordLabel);
	    panel.add(Box.createVerticalStrut(10)); 
	    panel.add(passwordField);
	    panel.add(Box.createVerticalStrut(10)); 

	    panel.add(submitButton);
	    panel.add(error);
	    error.setForeground(Color.red);

	    // add the panel to the frame
	    add(panel);


		submitButton.addActionListener(this);



	}
	
	
	
    // create a JPanel for form
    JPanel panel = new JPanel();

    
    JLabel greeting = new JLabel("Welcome to the Bank!");
    
    JLabel usernameLabel = new JLabel("username: "); 
    JTextField usernameField = new JTextField(15); 
    
    
    JLabel passwordLabel = new JLabel("password: "); 
    JPasswordField passwordField = new JPasswordField(20); 

       		

    JButton submitButton = new JButton("next");
    
    JLabel error = new JLabel(""); 
    
	
	
	
    
	
	// Error Analysis
		// Checks the entries of all the blanks in Main.addSavingsAccount()
		// adds details about errors to str error message 
		@Override
		public void actionPerformed(ActionEvent e)
		{ 	String str = "";
			Object source = e.getSource();
			// System.out.println(source);
	        
	        if(source == submitButton){

	        	// user name
	            String username = usernameField.getText().trim();
            	String hashed_username = Main.hashString(username);
            	String hash = "8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918"; // "admin"
            	
            	// password 
            	char[] passwordChars = passwordField.getPassword(); // retrieve the password entered in the field as a char array
            	String password = new String(passwordChars); // convert the char array to a String
            	String hashed_password = Main.hashString(password);
            	String hash1 = "8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918";
            	
            	
	            if (username.isEmpty() || password.isEmpty()) {
	                str += " An entry is blank.";  
	                
	               
	            } 
	                
	           if(!hashed_username.equals(hash) || !hashed_password.equals(hash)) {
	                
	                str += " Invalid username or password."; 
	                
	            }


	            
	            
	            
	            if (!str.isBlank()) {  // there is an error 
	            	
	            	error.setText(str);
	
	    	        }
	            else {
	            	
	            	if(hashed_username.equals(hash) && hashed_password.equals(hash1)) { // correct credentials
	            		dispose();
                		Main.first(); // means logged in
                		}
	            	
	            }

	        }
	        }
			
   



	
	
	



		}