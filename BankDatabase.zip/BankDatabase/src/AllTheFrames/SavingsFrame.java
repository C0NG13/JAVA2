package AllTheFrames;

import java.awt.event.*;
import javax.swing.*;
import java.awt.*;

import BankAccountManagementSystem.Main;
import BankAccountManagementSystem.SavingsAccount;



@SuppressWarnings("serial")
public class SavingsFrame extends JFrame implements ActionListener, ItemListener {
	//constructor
	public SavingsFrame()
	{
		super("New Savings Account Intake Form");  // JFrame window caption 
	    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // just closes this form
	    
	    panel.setBackground(new Color(101, 67, 33)); // brown
		   
	    
	     greeting.setForeground(Color.WHITE);
	     greeting1.setForeground(Color.WHITE);
	     nameLabel.setForeground(Color.WHITE);
	     emailLabel.setForeground(Color.WHITE);
	     phoneLabel.setForeground(Color.WHITE);
	     accountLabel.setForeground(Color.WHITE);
	     SavingsBalanceLabel.setForeground(Color.WHITE);
	     directionsLabel.setForeground(Color.WHITE);
	     
	     checkBox1.setForeground(Color.WHITE);
	     checkBox1.setBackground(new Color(101, 67, 33));
	     checkBox2.setForeground(Color.WHITE);
	     checkBox2.setBackground(new Color(101, 67, 33));

	     
	     setSize(600,620); 
	    
	    
		// dimensions and margins for box and fields mostly
	    FlowLayout flow = new FlowLayout(FlowLayout.LEFT);
	    setLayout(flow);
	    
	    
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS)); // vertical and
        panel.setAlignmentX(Component.LEFT_ALIGNMENT); // left panel alignment

	    panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // add margin around panel
	    
	    ownerName.setMaximumSize(new Dimension(300, 30)); 
	    ownerName.setPreferredSize(new Dimension(300, 30));
	    ownerName.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10)); // padding inside text field
	    
	    email.setMaximumSize(new Dimension(300, 30));
	    email.setPreferredSize(new Dimension(300, 30));
	    email.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10)); 

	    phoneNumber.setMaximumSize(new Dimension(300, 30));
	    phoneNumber.setPreferredSize(new Dimension(300, 30));
	    phoneNumber.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
	    
	    accountNumber.setMaximumSize(new Dimension(300, 30));
	    accountNumber.setPreferredSize(new Dimension(300, 30));
	    accountNumber.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10)); 
	    
	    SavingsBalanceField.setMaximumSize(new Dimension(300, 30));
	    SavingsBalanceField.setPreferredSize(new Dimension(300, 30));
	    SavingsBalanceField.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10)); 
	    
	   
	    depositField.setMaximumSize(new Dimension(300, 30));
	    depositField.setPreferredSize(new Dimension(300, 30));
	    depositField.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10)); 
	    
	    withdrawField.setMaximumSize(new Dimension(300, 30));
	    withdrawField.setPreferredSize(new Dimension(300, 30));
	    withdrawField.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10)); 
	    

		
	    //adding things to the panel
	    panel.add(greeting);
	    panel.add(Box.createVerticalStrut(10));
	    panel.add(greeting1);
	    panel.add(Box.createVerticalStrut(10));
	    panel.add(nameLabel);
	    panel.add(ownerName);
	    panel.add(Box.createVerticalStrut(10)); 
	    panel.add(emailLabel);
	    panel.add(email);
	    panel.add(Box.createVerticalStrut(10));  
	    panel.add(phoneLabel);
	    panel.add(phoneNumber);
	    panel.add(Box.createVerticalStrut(10)); 
	    panel.add(accountLabel);
	    panel.add(accountNumber);
	    panel.add(Box.createVerticalStrut(10)); 
	    panel.add(SavingsBalanceLabel);
	    panel.add(SavingsBalanceField);
	    panel.add(Box.createVerticalStrut(10));  
	    panel.add(Box.createVerticalStrut(10)); 
	   
	    
	    panel.add(directionsLabel); 
	    panel.add(Box.createVerticalStrut(10));  

	    ButtonGroup group = new ButtonGroup();
	    group.add(checkBox1); 
	    panel.add(checkBox1); panel.add(depositField); 
	    panel.add(Box.createVerticalStrut(10));  
	    group.add(checkBox2);
	    panel.add(checkBox2); panel.add(withdrawField); 
	    panel.add(Box.createVerticalStrut(10));  

	    panel.add(Box.createVerticalStrut(10)); 
	    
	    panel.add(submitButton);
	    panel.add(error);
	    error.setForeground(Color.red);

	    add(panel);


		submitButton.addActionListener(this);
		checkBox1.addActionListener(this);
		checkBox2.addActionListener(this);



	}
	
	
	
    JPanel panel = new JPanel();


    JLabel greeting = new JLabel("Welcome to the Bank!\n"); 
    JLabel greeting1 = new JLabel("Please fill out the form accurately to avoid system errors. \n Thank you!"); 

  
    JLabel nameLabel = new JLabel("Name:"); 
    JTextField ownerName = new JTextField(15);          		

    JLabel emailLabel = new JLabel("Email:");
    JTextField email  = new JTextField(15); 

    JLabel phoneLabel = new JLabel("Phone:");
    JTextField phoneNumber = new JTextField(15);  
    
    JLabel accountLabel = new JLabel("Account Number:");
    JTextField accountNumber = new JTextField(15); 
    
    JLabel SavingsBalanceLabel = new JLabel("Account Start Balance:");
    JTextField SavingsBalanceField = new JTextField(15);  
    
    JLabel directionsLabel = new JLabel("Please select the operation that you would like to do:");

    JCheckBox checkBox1 = new JCheckBox("Deposit, please enter a positive number:");
    JCheckBox checkBox2 = new JCheckBox("Withdraw, please enter a positive number:");

    JTextField depositField = new JTextField(10);  
    JTextField withdrawField = new JTextField(10);  
    
    JButton submitButton = new JButton("next");
    JLabel error = new JLabel(""); 
   
    
	
	
	
    
	
	// Error Analysis
		// Checks the entries of all the blanks in Main.addSavingsAccount()
		// adds details about errors to str error message 
		@Override
		public void actionPerformed(ActionEvent e)
		{ 	String str = "";
			Object source = e.getSource();
			// System.out.println(source);
	        // using the global variables
	        Main.setEmail(email.getText());
	        Main.setName(ownerName.getText());
	        Main.setPhone(phoneNumber.getText());
	        Main.setAccountNum(accountNumber.getText());
	        
	        if(source == submitButton){
				
				 if (Main.getEmail().isBlank() || Main.getPhone().isBlank() || Main.getName().isBlank()  || Main.getAccountNum().isBlank()) {
			        	str += "\nAn entry is blank.";}
			        
			        if (!Main.getEmail().contains("@") || !Main.getEmail().contains(".")) {
			        	str += "\nEmail does not contain either an @ sign or a dot.";}
			        
			        try {
			        	if (!SavingsBalanceField.getText().isBlank()) {
			        		Main.setBal(Double.parseDouble(SavingsBalanceField.getText()));
			        	}
			        
			        }
			        catch (Exception ex) {
			        	str += "\nIncorrect start balance entry: You did not provide a number.";
			        }
			        
			        
			        try {
			        	
			        	if( !depositField.getText().isBlank() ) {
			        			Main.setDepositIn(Math.abs(Double.parseDouble(depositField.getText())));}
			        	else if(!withdrawField.getText().isBlank()) {
			        		if(Double.parseDouble(withdrawField.getText()) <= Main.getBal()) { 
			        			Main.setWithdrawOut(Math.abs(Double.parseDouble(withdrawField.getText())));
			        			}
			        		else {
			        			str+= "\n Withdraw number is larger than account Balance. Try again.";
			        		}
			    		}
			        	
			        }
			        catch (Exception ex) {
			        	str += "\nIncorrect withdraw or deposit entry: You did not provide a number.";
			        } 
			        
			        
			       
			        
			        // displaying error message
			        if (!str.isBlank() ) {  // there is an error 
			        	error.setText(str);
			            }
			        else { 
			        	
			  	     
				      
				      //System.out.println("P:" + (Main.getP()) );
				      
				      Main.accounts[Main.getCount() -1 ] =  new SavingsAccount(accountNumber.getText(), ownerName.getText(), email.getText(), phoneNumber.getText(), Main.getBal());
				      Main.count++; // or setCount(count +1);
				      
				      //System.out.println(save.toString());
			        
				       if (Main.getCount() <= Main.getP()) {
				        dispose();
				        Main.second();
				       }
				       else { // Main.getCount() = Main.getP()
				        dispose();
				        	
				       Main.displayAccountInfo(Main.accounts);
			        }
				        
			        
			        }
	        }

	      
	        }
			
   


    
    // what to do if a check box is checked or not
	@Override
	public void itemStateChanged(ItemEvent e) {
		int select = e.getStateChange();
		Object source = e.getItem();
		if(source == checkBox1) // deposit
		{
			
			if(select == ItemEvent.SELECTED)
			{
				try {
					if (!SavingsBalanceField.getText().isBlank()) {
		        		Main.setBal(Double.parseDouble(SavingsBalanceField.getText()));
		        	}

					if( !depositField.getText().isBlank() ) {
		    		Main.setDepositIn(Math.abs(Double.parseDouble(depositField.getText())));
		    		
		    		Main.deposit(Main.accounts[Main.count - 1], Main.getDepositIn(), Main.getBal());
		    		
		    		}

		        	else {
		        		Main.setDepositIn(0.0);
		        	}
		        }
		        catch (Exception ex) {
		        	System.out.println("Error with deposit field");
		        }
			}	}
				
		else if(source == checkBox2) // withdraw
		{
			
			if(select == ItemEvent.SELECTED)
			{
				try {
					if (!SavingsBalanceField.getText().isBlank()) {
		        		Main.setBal(Double.parseDouble(SavingsBalanceField.getText()));
		        	}

					if( !withdrawField.getText().isBlank() ) {
		    		Main.setWithdrawOut(Math.abs(Double.parseDouble(withdrawField.getText())));
		    		
		    		Main.withdraw(Main.accounts[Main.count - 1], Main.getWithdrawOut(), Main.getBal());
		    		
		    		}

		        	else {
		        		Main.setWithdrawOut(0.0);
		        	}
		        }
		        catch (Exception ex) {
		        	System.out.println("Error with withdraw field");
		        }

				
		}}


	
	
	}}

