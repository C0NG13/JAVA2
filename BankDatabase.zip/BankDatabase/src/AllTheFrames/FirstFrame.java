package AllTheFrames;

import java.awt.event.*;
import javax.swing.*;
import java.awt.*;

import BankAccountManagementSystem.Main;


@SuppressWarnings("serial")
public class FirstFrame extends JFrame implements ActionListener {
	//constructor
	public FirstFrame()
	{
		super("90's Start Window");  // JFrame window caption 
	    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // just closes this form
	    
	    panel.setBackground(new Color(0, 0, 128)); // navy blue
		   
	    
	     greeting.setForeground(Color.WHITE);
	     greeting1.setForeground(Color.WHITE);
	     numLabel.setForeground(Color.WHITE);
	     
	     setSize(400,230); 
	    
	    
		// dimensions and margins for box and fields mostly
	    FlowLayout flow = new FlowLayout(FlowLayout.LEFT);
	    setLayout(flow);
	    
	    
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS)); // vertical and
        panel.setAlignmentX(Component.LEFT_ALIGNMENT); // left panel alignment

	    panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // add margin around panel
	    
	    numField.setMaximumSize(new Dimension(300, 30)); 
	    numField.setPreferredSize(new Dimension(300, 30));
	    numField.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10)); // padding inside text field
	    


		
	    //adding things to the panel
	    panel.add(greeting);
	    panel.add(Box.createVerticalStrut(10));
	    panel.add(greeting1);
	    panel.add(Box.createVerticalStrut(10));
	    panel.add(numLabel);
	    panel.add(Box.createVerticalStrut(10));  // add spacing between components
	    panel.add(numField);
	    panel.add(Box.createVerticalStrut(10));  

	    panel.add(submitButton);
	    panel.add(error);
	    error.setForeground(Color.red);

	    // add the panel to the frame
	    add(panel);


		submitButton.addActionListener(this);



	}
	
	
	
    // create a JPanel for form
    JPanel panel = new JPanel();

    
    JLabel greeting = new JLabel("Welcome to the Bank!\n"); 
    JLabel greeting1 = new JLabel("How many accounts would you like to make today?"); 

    JLabel numLabel = new JLabel("Please enter an integer:"); 
    JTextField numField = new JTextField(15);        		

    JButton submitButton = new JButton("next");
    
    JLabel error = new JLabel(""); 
    
	
	
	
    
	
	// Error Analysis
		// Checks the entries of all the blanks in Main.addSavingsAccount()
		// adds details about errors to str error message 
		@Override
		public void actionPerformed(ActionEvent e)
		{ 	String str = "";
			Object source = e.getSource();
			// System.out.println(source);
	        
	        if(source == submitButton){

	            String text = numField.getText().trim();  // remove leading and trailing whitespace This seems useful, yet I am not that motivated to use it that often.
	            if (text.isEmpty()) {
	                str += "\nEntry is blank.";  
	            } else {
	                try {
	                	int p = Math.abs(Integer.parseInt(numField.getText()));
	                	if(p == 0) {
	                		str += "No, you cannot have zero accounts.";
	                	}
	                	else {
	                	Main.setP(p);
	                	// System.out.println(Main.getP()); // error testing stuff

	                	Main.second(); // go to next step: select account type
	                	dispose(); // close last frame
	                	}
	                	
	                	
	                } catch (NumberFormatException ex) {
	                    str += "\nInvalid number entered. That was not an integer"; 
	                }
	            }
	            
	            if (!str.isBlank()) {  // there is an error 
	            	
	            	error.setText(str);
	
	    	        }

	        }
	        }
			
   



	
	
	



		}