package AllTheFrames;

import java.awt.event.*;
import javax.swing.*;
import java.awt.*;

import BankAccountManagementSystem.Main;



@SuppressWarnings("serial")
public class SecondFrame extends JFrame implements ActionListener {

	//constructor
	public SecondFrame()
	{
		super("New Account Intake Form");  // JFrame window caption 
	    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // just closes this form
	    
	    panel.setBackground(new Color(0, 100, 0)); // dark green
		   
	    
	     greeting.setForeground(Color.WHITE);
	     greeting1.setForeground(Color.WHITE);
	     
	     setSize(400,300); 
	    
	    
	    
		// dimensions and margins for box and fields mostly
	    FlowLayout flow = new FlowLayout(FlowLayout.LEFT);
	    setLayout(flow);
	    
	    
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS)); // vertical and
        panel.setAlignmentX(Component.LEFT_ALIGNMENT); // left panel alignment

	    panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // add margin around panel

	    //adding things to the panel
	    panel.add(greeting);
	    panel.add(Box.createVerticalStrut(10));
	    panel.add(greeting1);
	    panel.add(Box.createVerticalStrut(10));
	    panel.add(Box.createVerticalStrut(10));  

	    panel.add(Button1);
	    panel.add(Box.createVerticalStrut(10));  
	    panel.add(Button2); 
	    panel.add(Box.createVerticalStrut(10));  
	    panel.add(Button3);
	    panel.add(Box.createVerticalStrut(10));  
	    panel.add(Button4);
	    panel.add(Box.createVerticalStrut(10));  

	    add(panel);


		Button1.addActionListener(this);
		Button2.addActionListener(this);
		Button3.addActionListener(this);
		Button4.addActionListener(this);


	}
	
	
	

    JPanel panel = new JPanel();


    JLabel greeting = new JLabel("Welcome to the Bank!\n"); 
    JLabel greeting1 = new JLabel("Please select what type of account you would like to create:"); 

    JButton Button1 = new JButton("Savings");
    JButton Button2 = new JButton("Checking");
    JButton Button3 = new JButton("Crypto");
    JButton Button4 = new JButton("Mutual Fund");

	
    
	
// Error Analysis
 
    // what to do if a check box is checked or not
	@Override
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		System.out.println(source);
		if(source == Button1) // savings
		{	

				dispose(); // closes the last second() form
		    	
		    	Main.addSavingsAccount();}
				
		else if(source == Button2) // Checking
		{
				Main.addCheckingAccount();
		    	dispose(); // closes the last second() form
		    	}
	
		else if(source == Button3) // Crypto
		{
				Main.addCryptoAccount();
		    	dispose(); // closes the last second() form
			}
		
		else if(source == Button4) // Mutual Fund
		{		
				Main.addMutualFundAccount();
		    	dispose(); // closes the last second() form
			}
		
		}}