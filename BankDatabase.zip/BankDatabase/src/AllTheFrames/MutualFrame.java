package AllTheFrames;

import java.awt.event.*;
import javax.swing.*;
import java.awt.*;

import BankAccountManagementSystem.Main;
import BankAccountManagementSystem.MutualFundAccount;


@SuppressWarnings("serial")
public class MutualFrame extends JFrame implements ActionListener, ItemListener {
	//constructor
	public MutualFrame()
	{
		
		
		super("New Mutual Account Intake Form");  // JFrame window caption 
	    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // just closes this form	
	    
	    panel.setBackground(new Color(101, 67, 33)); // brown
		   
	    
	     greeting.setForeground(Color.WHITE);
	     greeting1.setForeground(Color.WHITE);
	     nameLabel.setForeground(Color.WHITE);
	     emailLabel.setForeground(Color.WHITE);
	     phoneLabel.setForeground(Color.WHITE);
	     accountLabel.setForeground(Color.WHITE);
	     BalanceLabel.setForeground(Color.WHITE);
	     directionsLabel.setForeground(Color.WHITE);
	     MutualBalanceLabel.setForeground(Color.WHITE);
	     label.setForeground(Color.WHITE);
	     
	     comboBox.setBackground(new Color(101, 67, 33));
	     comboBox.setForeground(Color.WHITE); 

	     

	     
	     checkBox1.setForeground(Color.WHITE);
	     checkBox1.setBackground(new Color(101, 67, 33));
	     checkBox2.setForeground(Color.WHITE);
	     checkBox2.setBackground(new Color(101, 67, 33));

	     
	     setSize(620,720); 
	    
		// dimensions and margins for box and fields mostly
	    FlowLayout flow = new FlowLayout(FlowLayout.LEFT);
	    setLayout(flow);
	    
	    
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS)); // vertical and
        panel.setAlignmentX(Component.LEFT_ALIGNMENT); // left panel alignment

	    panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // add margin around panel
	    
	    ownerName.setMaximumSize(new Dimension(300, 30)); 
	    ownerName.setPreferredSize(new Dimension(300, 30));
	    ownerName.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10)); // padding inside text field
	    
	    email.setMaximumSize(new Dimension(300, 30));
	    email.setPreferredSize(new Dimension(300, 30));
	    email.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10)); 

	    phoneNumber.setMaximumSize(new Dimension(300, 30));
	    phoneNumber.setPreferredSize(new Dimension(300, 30));
	    phoneNumber.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
	    
	    accountNumber.setMaximumSize(new Dimension(300, 30));
	    accountNumber.setPreferredSize(new Dimension(300, 30));
	    accountNumber.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10)); 
	    
	    BalanceField.setMaximumSize(new Dimension(300, 30)); 			
	    BalanceField.setPreferredSize(new Dimension(300, 30));
	    BalanceField.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10)); 
	    
	    MutualBalanceField.setMaximumSize(new Dimension(300, 30));
	    MutualBalanceField.setPreferredSize(new Dimension(300, 30));
	    MutualBalanceField.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10)); 
	    
	   
	    depositField.setMaximumSize(new Dimension(300, 30));
	    depositField.setPreferredSize(new Dimension(300, 30));
	    depositField.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10)); 
	    
	    withdrawField.setMaximumSize(new Dimension(300, 30));
	    withdrawField.setPreferredSize(new Dimension(300, 30));
	    withdrawField.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10)); 
	    
	    
	    comboBox.setMaximumSize(new Dimension(300, 30));
	    comboBox.setPreferredSize(new Dimension(300, 30));
	    comboBox.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10)); 
	    

		
	    //adding things to the panel
	    panel.add(greeting);
	    panel.add(Box.createVerticalStrut(10));
	    panel.add(greeting1);
	    panel.add(Box.createVerticalStrut(10));
	    panel.add(nameLabel);
	    panel.add(ownerName);
	    panel.add(Box.createVerticalStrut(10));  // add spacing between components
	    panel.add(emailLabel);
	    panel.add(email);
	    panel.add(Box.createVerticalStrut(10));  
	    panel.add(phoneLabel);
	    panel.add(phoneNumber);
	    panel.add(Box.createVerticalStrut(10));  
	    panel.add(accountLabel);
	    panel.add(accountNumber);
	    panel.add(Box.createVerticalStrut(10));  
	    panel.add(BalanceLabel);
	    panel.add(BalanceField);
	    panel.add(Box.createVerticalStrut(10)); 
	    panel.add(MutualBalanceLabel);
	    panel.add(MutualBalanceField);
	    panel.add(Box.createVerticalStrut(10)); 
	   
        panel.add(label);
        panel.add(comboBox);
        panel.add(Box.createVerticalStrut(10));  
	    
	    panel.add(directionsLabel);
	    panel.add(Box.createVerticalStrut(10));  
		
	    ButtonGroup group = new ButtonGroup();
	    group.add(checkBox1); 
	    panel.add(checkBox1); panel.add(depositField);
	    panel.add(Box.createVerticalStrut(10)); 
	    group.add(checkBox2);
	    panel.add(checkBox2); panel.add(withdrawField); 
	    panel.add(Box.createVerticalStrut(10)); 

	    panel.add(Box.createVerticalStrut(10));  
	    
	    panel.add(submitButton);
	    panel.add(error);
	    error.setForeground(Color.red);

	    add(panel);


		submitButton.addActionListener(this);
		checkBox1.addActionListener(this);
		checkBox2.addActionListener(this);



	}
	
	
	
    JPanel panel = new JPanel();

    JLabel greeting = new JLabel("Welcome to the Bank!\n"); 
    JLabel greeting1 = new JLabel("Please fill out the form accurately to avoid system errors. \n Thank you!"); 

    JLabel nameLabel = new JLabel("Name:"); 
    JTextField ownerName = new JTextField(15);  	

    JLabel emailLabel = new JLabel("Email:");
    JTextField email  = new JTextField(15); 

    JLabel phoneLabel = new JLabel("Phone:");
    JTextField phoneNumber = new JTextField(15);  
    
    JLabel accountLabel = new JLabel("Account Number:");
    JTextField accountNumber = new JTextField(15); 
    
    JLabel BalanceLabel = new JLabel("Account Start Balance:");
    JTextField BalanceField = new JTextField(15);  
    
    JLabel MutualBalanceLabel = new JLabel("Mutual Account Start Balance:");
    JTextField MutualBalanceField = new JTextField(15);  
    
    // Create the dropdown menu (JComboBox) with some items
    String[] options = { "Low", "Medium", "High" };
    JComboBox<String> comboBox = new JComboBox<>(options);
    JLabel label = new JLabel("Risk Level:");
    
    JLabel directionsLabel = new JLabel("Please select the operation that you would like to do:");
    
    JCheckBox checkBox1 = new JCheckBox("Deposit for Mutual Account, please enter a positive number:");
    JCheckBox checkBox2 = new JCheckBox("Withdraw from regular account, please enter a positive number:");
    
    JTextField depositField = new JTextField(10);  
    JTextField withdrawField = new JTextField(10);
    
    JButton submitButton = new JButton("next");
    JLabel error = new JLabel(""); 
   
    
	
	
	
    
	
	// Error Analysis
		// Checks the entries of all the blanks in Main.addSavingsAccount()
		// adds details about errors to str error message 
		@Override
		public void actionPerformed(ActionEvent e)
		{ 	String str = "";
			Object source = e.getSource();
			//System.out.println(source);
	        // using the global variables
	        Main.setEmail(email.getText());
	        Main.setName(ownerName.getText());
	        Main.setPhone(phoneNumber.getText());
	        Main.setAccountNum(accountNumber.getText());
	        
	        if(source == submitButton){
				
				 if (Main.getEmail().isBlank() || Main.getPhone().isBlank() || Main.getName().isBlank()  || Main.getAccountNum().isBlank()) {
			        	str += "\nAn entry is blank.";}
			        
			        if (!Main.getEmail().contains("@") || !Main.getEmail().contains(".")) {
			        	str += "\nEmail does not contain either an @ sign or a dot.";}
			        
			        try {
			        	if (!BalanceField.getText().isBlank()) {
			        		Main.setBal(Double.parseDouble(BalanceField.getText()));
			        	}
			        
			        }
			        catch (Exception ex) {
			        	str += "\nIncorrect start balance entry: You did not provide a number.";
			        }
			        
			        double investBal = 0.0;
			        try {
			        	if (!MutualBalanceField.getText().isBlank()) {
			        		investBal = Double.parseDouble(MutualBalanceField.getText());
			        		
			        	}
			        
			        }
			        catch (Exception ex) {
			        	str += "\nIncorrect start balance entry for Mutual Fund Account: You did not provide a number.";
			        }

			        
			        try {
			        	
			        	if( !depositField.getText().isBlank() ) {
			        			Main.setDepositIn(Math.abs(Double.parseDouble(depositField.getText())));}
			        	else if(!withdrawField.getText().isBlank()) {
			        		if(Double.parseDouble(withdrawField.getText()) <= Main.getBal()) { 
			        			Main.setWithdrawOut(Math.abs(Double.parseDouble(withdrawField.getText())));
			        			}
			        		else {
			        			str+= "\n Withdraw number is larger than account Balance. Try again.";
			        		}
			    		}
			        	
			        }
			        catch (Exception ex) {
			        	str += "\nIncorrect withdraw or deposit entry: You did not provide a number.";
			        } 
			        
			        
			        
					if (comboBox.getSelectedIndex() == -1) { // not selected
						
						str += "Risk Level not selected.";
					}
				
			        
			        // displaying error message
			        if (!str.isBlank() ) {  // there is an error 
			        	error.setText(str);
			            }
			        else { 
			        	
			  	     
			        	String selectedOption = (String) comboBox.getSelectedItem(); // making selection a string   
				     // System.out.println("P value:" + (Main.getP()) );
				      
				      Main.accounts[Main.getCount() - 1 ] =  new MutualFundAccount(accountNumber.getText(), ownerName.getText(), email.getText(), phoneNumber.getText(), Main.getBal(), investBal, selectedOption);
				     
				     
				      
				      Main.count++; // or setCount(count +1);
				      
				      //System.out.println(save.toString()); // error testing stuff
			        
				       if (Main.getCount() <= Main.getP()) {
				        dispose();
				        Main.second();
				       }
				       else { // Main.getCount() = Main.getP()
				        dispose();
				        	
				       Main.displayAccountInfo(Main.accounts);
			        }
				        
			        
			        }
			        
			        

	        }

	      
	        }
			
   

		



    // what to do if a check box is checked or not
	@Override
	public void itemStateChanged(ItemEvent e) {
		int select = e.getStateChange();
		Object source = e.getItem();
		if(source == checkBox1) // deposit
		{
			
			if(select == ItemEvent.SELECTED)
			{
				try {
					if (!BalanceField.getText().isBlank()) {
		        		Main.setBal(Double.parseDouble(BalanceField.getText()));
		        	}

					if( !depositField.getText().isBlank() ) {
		    		Main.setDepositIn(Math.abs(Double.parseDouble(depositField.getText())));
		    		
		    		Main.deposit(Main.accounts[Main.count - 1], Main.getDepositIn(), Double.parseDouble((MutualBalanceField).getText()));
		    		
		    		}

		        	else {
		        		Main.setDepositIn(0.0);
		        	}
		        }
		        catch (Exception ex) {
		        	System.out.println("Error with deposit field"); // error testing stuff
		        }
			}	}
				
		else if(source == checkBox2) // withdraw
		{
			
			if(select == ItemEvent.SELECTED)
			{
				try {
					if (!BalanceField.getText().isBlank()) {
		        		Main.setBal(Double.parseDouble(BalanceField.getText()));
		        	}

					if( !withdrawField.getText().isBlank() ) {
		    		Main.setWithdrawOut(Math.abs(Double.parseDouble(withdrawField.getText())));
		    		
		    		Main.withdraw(Main.accounts[Main.count - 1], Main.getWithdrawOut(), Main.getBal());
		    		
		    		}

		        	else {
		        		Main.setWithdrawOut(0.0);
		        	}
		        }
		        catch (Exception ex) {
		        	System.out.println("Error with withdraw field"); // error testing stuff
		        }

				
		}}
		


	
	
	}}

