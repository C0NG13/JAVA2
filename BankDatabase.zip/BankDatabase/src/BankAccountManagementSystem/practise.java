
package BankAccountManagementSystem;


import javax.swing.*;
import java.awt.*;


public class practise {

	    public static void main(String[] args) {
	        // Create a JFrame
	        JFrame frame = new JFrame("Custom Window");
	        frame.setSize(400, 300);
	        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	        // Set the background color of the entire window to black
	        frame.getContentPane().setBackground(Color.BLACK);

	        // Create a JPanel for the white top edge
	        

	        // Add components to the frame
	        frame.setLayout(new BorderLayout());
	       // frame.add(topEdgePanel, BorderLayout.NORTH);  // Add white panel to the top
	        frame.add(new JLabel("Content goes here", SwingConstants.CENTER), BorderLayout.CENTER);  // Add content in the center

	        // Set the frame to be visible
	        frame.setVisible(true);
	    }
	}

	