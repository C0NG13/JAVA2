package BankAccountManagementSystem;

public class BankAccount {
	//Attributes
	private String accountNumber;
	private String ownerName;
	private String email;
	private String phoneNumber;
	private double balance;
	
	//Constructor 
	public BankAccount(String accountNumber, String ownerName, String email, String phoneNumber, double balance) { 
		this.accountNumber = accountNumber;
		this.ownerName = ownerName; 
		this.email = email; 
		this.phoneNumber = phoneNumber; 
		this.balance = balance;

	}	
	
	//Getters and Setters
	public String getAccountNumber() {
		return accountNumber;
		}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
		}
	public String getOwnerName() {
		return ownerName;
		}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
		}
	public String getEmail() {
		return email;
		}
	public void setEmail(String email) {
		this.email = email;
		}
	public String getPhoneNumber() {
		return phoneNumber;
		}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
		}
	public double getBalance() {
		return balance;
		}
	public void setBalance(double balance) {
		this.balance = balance;
		}
	



	

    public String toString() { 
    	return "<br/>Type: Bank Account <br/>" + "Balance: " + balance +
    			"<br/>Account Number: " + accountNumber + "<br/>Name: " + ownerName + "<br/>Email: " + email + "<br/>Phone: " + phoneNumber + "<br/>Balance: " + balance ; 

    	}
	

	
	
}



 