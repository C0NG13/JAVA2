package BankAccountManagementSystem;

public class CryptoAccount extends BankAccount{

private double cryptoBalance;
private String cryptoType;
	
    public CryptoAccount (String accountNumber, String ownerName, String email, String phoneNumber, double balance, String type) {
    	super(accountNumber, ownerName, email, phoneNumber, balance); 
    	cryptoBalance = 3.14*this.getBalance();
    	this.cryptoType = type; 
    	
    	}
	
	public double getCryptoBalance() {
		cryptoBalance = 3.14*this.getBalance();
		return cryptoBalance;
		}
	public String getRiskLevel() {  
		return cryptoType;
		}
	public void setRiskLevel(String type) {
		this.cryptoType = type;
		}
	

	
    public String toString() { 
    	return "<br/>Type: Crypto Account <br/>" + "Balance in $: " + getBalance() + 
    			"<br/>Account Number: " + getAccountNumber() + "<br/>Name: " + getOwnerName() + "<br/>Email: " + getEmail() + "<br/>Phone: " + getPhoneNumber() + "<br/>Balance: " + getBalance()  
    			+ "<br/>Crypto Balance: " + cryptoBalance + "<br/>Crypto Type: " + cryptoType  ;
    			
    	}
}