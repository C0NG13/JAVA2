
// The password and user name are both admin


package BankAccountManagementSystem;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import AllTheFrames.*;




public class Main { 
	
	// client global variables
	public static String Name; // I am using these second set of attributes to verify that the input 
	public static String Email; // is accurate before assigning it to the actual attributes in the Parent Class.
	public static String Phone;
	public static String AccountNum;
	
	public static int p; // total number of accounts
	public static int count = 1; // where we are ... index will be count -1 
	
	
	
	// all balance related global variables
	public static double Bal; 
	public static double start;
	public static double in;
	public static double out;
	
	public static BankAccount[] accounts;
	
	// getters and setters
	public static void setName(String name) {
		Name = name;
		}
	public   static  String getName() {
		return Name;
		}

	public  static void setEmail(String email) {
		Email = email;
		}
	public   static  String getEmail() {  
		return Email;
		}
	public  static  void setPhone(String phone) {
		Phone = phone;
		}
	public   static  String getPhone() {
		return Phone;
		}
	public  static  void setAccountNum(String accountNum) {
		AccountNum = accountNum;
		}
	public   static  String getAccountNum() {
		return AccountNum;
		}
	public  static  void setP(int P) { // assigns p to the BankAccount object
		p = P;
		accounts = new BankAccount[P]; // iterates through to develop p number of objects with null information 
		for (int i = 0; i < P; i++) { // upon initialization (granting p a value by user)
			accounts[i] = new BankAccount(null, null, null, null, 0.0);
		}
		
		}
	public  static   int getP() {
		return p;
		
		}
	public  static  void setCount(int Count) {
		count = Count;
		}
	public   static  int getCount() {
		return count;
		}
	public  static  void setBal(double bal) {
		Bal = bal;
		}
	public   static  double getBal() {
		return Bal;
		}
	public static void setStartBalance(double Start) {
		start = Start;
		}
	public   static  double getStartBalance() {
		return start;
		}
	public  static  void setDepositIn(double IN) {
		in = IN;
		}
	public  static   double getDepositIn() {
		return in;
		}
	public  static  void setWithdrawOut(double OUT) {
		out = OUT;
		}
	
	public  static   double getWithdrawOut() {
		return out;
		}
	
	
	public static void main(String[] args) {
	
	 login(); // if you enter the correct credentials, then hint "admin"
		
	// first();  // how many accounts would you like to make?	p
	
	
	
	//accounts = new BankAccount[p]  user decides the size of the array  see Main.setP(int P) for details
	
	// second(); what type of account would you like to create? savings, checking, crypto, mutual fund?
	
	// proceed to make p number of accounts
	// add???AccountType(); 
	
	// when count = p 
	// displayAccountInfo();
	
	// click finish button and the program is done
	
	

	}
	
	
	
	public static void login() {
		
        LoginFrame frame = new LoginFrame(); // create an instance of JMyFrame and make it visible
        frame.setVisible(true);
	   
    } 
	

	public static void first() {
		
        FirstFrame frame = new FirstFrame(); // create an instance of JMyFrame and make it visible
        frame.setVisible(true);
	   
    } 
	

	public static void second() {
        SecondFrame frame = new SecondFrame();
        frame.setVisible(true);		
    } 
	

	public static void deposit(BankAccount account, double in, double start) {
		
		
		account.setBalance(start + in); 
		
		
	}
	
	
	public static void withdraw(BankAccount account, double start, double out) {
		
		account.setBalance(start - out);
		
		
	}
	
	public static void displayAccountInfo(BankAccount[] account) { 
		
		
		
		 StringBuilder message = new StringBuilder(); // make string builder
		 for (BankAccount accounts: account) {
	            message.append(accounts.toString()).append("<br/> <br/> <br/>");
	      }
		 
		 System.out.println(message.toString());
		 
	     DisplayAllFrame frame = new DisplayAllFrame("<html>" + message.toString() + "</html>");
	     frame.setVisible(true);
	     
	     
	        
	}
	
	
	

	public static void addSavingsAccount() {
	
        SavingsFrame frame = new SavingsFrame();
        frame.setVisible(true);
    } 
	
	
	public static void addCheckingAccount() {
	
        CheckingFrame frame = new CheckingFrame();
        frame.setVisible(true);
    } 
	

	public static void addCryptoAccount() {

		CryptoFrame frame = new CryptoFrame();
        frame.setVisible(true);
    } 
	

	public static void addMutualFundAccount() {

		MutualFrame frame = new MutualFrame();
        frame.setVisible(true);
    } 
	
    
	public static String hashString(String input) {
        try {
            // Create a MessageDigest instance for SHA-256
            MessageDigest digest = MessageDigest.getInstance("SHA-256");

            // Perform the hash computation
            byte[] hashedBytes = digest.digest(input.getBytes());

            // Convert the byte array into a hex string
            StringBuilder hexString = new StringBuilder();
            for (byte b : hashedBytes) {
                hexString.append(String.format("%02x", b));
            }

            // Return the hex string (hashed output)
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            // If the algorithm is not available, handle the exception
            e.printStackTrace();
        }
        return null;
    }
	


}