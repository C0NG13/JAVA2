package BankAccountManagementSystem;

public class SavingsAccount extends BankAccount {

	private double interestRate;
	
    public SavingsAccount (String accountNumber, String ownerName, String email, String phoneNumber, double balance) {
    	super(accountNumber, ownerName, email, phoneNumber, balance); 
    	interestRate = 1.098;
    	}
	
	public double getInterestRate() {
		return interestRate;
		}
	
	

	
    public String toString() { 

		
    	return "<br/> Type: Savings Account <br/>" + "Balance: $" + getBalance() + "<br/> \nAccount Number: " + getAccountNumber()
    	+ "<br/> \nName: " + getOwnerName() +	"<br/> \nEmail: " + getEmail() + "<br/> \nPhone: " + getPhoneNumber() 
    	+ " <br/> \nBalance: " + getBalance()  + "<br/> \nInterest Rate: " + interestRate;
    			
    	}
	
}
