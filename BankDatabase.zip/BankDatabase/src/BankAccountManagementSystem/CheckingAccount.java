package BankAccountManagementSystem;

public class CheckingAccount  extends BankAccount{
	
	private double overdraftLimit;
	
    public CheckingAccount (String accountNumber, String ownerName, String email, String phoneNumber, double balance) {
    	super(accountNumber, ownerName, email, phoneNumber, balance); 
    	overdraftLimit = 1000.0;
    	}
	
	public double getOverdraft() {
		return overdraftLimit;
		}

	
    public String toString() { 
    	return "<br/>Type: Checking Account <br/>" + "Balance: " + this.getBalance() +
    			"<br/>Account Number: " + getAccountNumber() + "vName: " + getOwnerName() + "<br/>Email: " + getEmail() + 
    			"<br/>Phone: " + getPhoneNumber() + "<br/>Overdraft Limit: " + overdraftLimit  ;
    			
    	}


}
