package BankAccountManagementSystem;

public class MutualFundAccount extends BankAccount{

	//o	investmentBalance (double)
	// riskLevel (String) → Values: "Low", "Medium", "High"

private double investmentBalance;
private String riskLevel;
	
    public MutualFundAccount (String accountNumber, String ownerName, String email, String phoneNumber, double balance, double investmentBalance, String risk) {
    	super(accountNumber, ownerName, email, phoneNumber, balance); 
    	this.investmentBalance = investmentBalance;
    	this.riskLevel = risk; 
    	
    	}
	
	public double getInvestmentBalance() {
		return investmentBalance;
		}
	public void setInvestmentBalance(double investBalance) {
		investmentBalance = investBalance;
		}
	public String getRiskLevel() {
		return riskLevel;
		}
	public void setRiskLevel(String risk) {
		this.riskLevel = risk;
		}
	

	
    public String toString() { 
    	return "<br/>Type: Bank Account <br/>" +
    			"Account Number: " + getAccountNumber() + "<br/>Name: " + getOwnerName() + "<br/>Email: " + getEmail() + "<br/>Phone: " + getPhoneNumber() + "<br/>Balance: " + getBalance()  
    			+ "<br/>Investment Balance: " + investmentBalance + "<br/>Risk Level: " + riskLevel  ;
    			
    	}
}
